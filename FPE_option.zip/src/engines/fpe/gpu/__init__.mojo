"""GPU module for FPE."""
